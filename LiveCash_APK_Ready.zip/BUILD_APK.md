# بناء APK لـ LiveCash

هذا المشروع يحتوي على كود Flutter فقط، ويقوم GitHub Actions بإنشاء ملفات Android تلقائياً ثم يبني نسخة Release APK.

## من GitHub
1. ارفع ملفات المشروع إلى المستودع.
2. افتح تبويب **Actions**.
3. اختر **Build LiveCash APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء افتح التشغيل الناجح وحمّل artifact باسم `livecash-release-apk`.

> تسجيل Firebase/Google Sign-In لن يعمل فعلياً حتى تتم إضافة إعدادات Firebase الخاصة بالتطبيق. الواجهة الحالية تجريبية.
