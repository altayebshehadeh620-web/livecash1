import 'package:flutter/material.dart';

void main() => runApp(const LiveCashApp());

class LiveCashApp extends StatelessWidget {
  const LiveCashApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LiveCash',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0813),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB86BFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeTab(),
      const RoomsTab(),
      const GamesTab(),
      const WalletTab(),
      const ProfileTab(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: const Color(0xFF120D1C),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.mic_none), label: 'المايكات'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), label: 'الألعاب'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'المحفظة'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showLiveDialog(context),
        icon: const Icon(Icons.videocam),
        label: const Text('ابدأ بث'),
      ),
    );
  }

  void _showLiveDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF171020),
      builder: (_) => const Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('إنشاء بث مباشر', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            ListTile(leading: Icon(Icons.videocam), title: Text('بث فيديو'), subtitle: Text('كاميرا + دردشة + هدايا')),
            ListTile(leading: Icon(Icons.mic), title: Text('غرفة مايكات'), subtitle: Text('من 2 إلى 20 مقعداً')),
          ],
        ),
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 90),
    children: [
      Row(children: [
        const Expanded(child: Text('LiveCash', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ]),
      const SizedBox(height: 16),
      _banner('عجلة الحظ المجانية 🎡', 'دعوة ناجحة = لفة مجانية', Icons.casino),
      const SizedBox(height: 18),
      const Text('البثوث المباشرة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      SizedBox(height: 190, child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: 5,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => Container(
          width: 145,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(
              colors: [Colors.deepPurple.shade900, Colors.pink.shade700],
              begin: Alignment.bottomLeft, end: Alignment.topRight),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Align(alignment: Alignment.bottomLeft,
              child: Text('مباشر • مضيف ${i+1}', style: const TextStyle(fontWeight: FontWeight.bold))),
          ),
        ),
      )),
      const SizedBox(height: 22),
      const Text('غرف المايكات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...List.generate(3, (i) => Card(
        color: const Color(0xFF171020),
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.mic)),
          title: Text('غرفة الأصدقاء ${i+1}'),
          subtitle: Text('${[4, 10, 20][i]} مقاعد • هدايا وألعاب'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {},
        ),
      )),
    ],
  );

  static Widget _banner(String title, String sub, IconData icon) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(colors: [Color(0xFF5A189A), Color(0xFFB5179E)]),
    ),
    child: Row(children: [
      CircleAvatar(radius: 28, backgroundColor: Colors.white24, child: Icon(icon, size: 30)),
      const SizedBox(width: 14),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        Text(sub),
      ]),
    ]),
  );
}

class RoomsTab extends StatelessWidget {
  const RoomsTab({super.key});
  @override
  Widget build(BuildContext context) => _SimplePage(
    title: 'غرف المايكات',
    icon: Icons.mic,
    children: [
      const Text('اختَر عدد المقاعد عند إنشاء الغرفة:'),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [2,4,6,8,10,12,16,20].map((n) => Chip(label: Text('$n مايك'))).toList()),
      const SizedBox(height: 24),
      const Text('داخل الغرفة: هدايا • ألعاب • مشرفون • كتم • قفل مايكات'),
    ],
  );
}

class GamesTab extends StatelessWidget {
  const GamesTab({super.key});
  @override
  Widget build(BuildContext context) => _SimplePage(
    title: 'الألعاب',
    icon: Icons.sports_esports,
    children: [
      _game('🎡 عجلة الدعوات', 'مجانية — لفة لكل دعوة ناجحة'),
      _game('🎯 تحدي الغرفة', 'الفائز يحصل على مكافأة كونزا'),
      _game('🏆 منافسات المايكات', 'تحديات بين المشاركين'),
    ],
  );
  Widget _game(String t, String s) => Card(
    color: const Color(0xFF171020),
    child: ListTile(leading: const Text('🎮', style: TextStyle(fontSize: 30)), title: Text(t), subtitle: Text(s)),
  );
}

class WalletTab extends StatelessWidget {
  const WalletTab({super.key});
  @override
  Widget build(BuildContext context) => _SimplePage(
    title: 'المحفظة',
    icon: Icons.account_balance_wallet,
    children: [
      _balance('كونزا', '0', 'عملة الشحن والهدايا'),
      _balance('فُل', '0', 'رصيد الأرباح'),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add_card), label: const Text('اشحن كونزا')),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.payments_outlined), label: const Text('اسحب الأرباح')),
      const SizedBox(height: 12),
      const Card(child: ListTile(leading: Icon(Icons.account_balance), title: Text('شام كاش'), subtitle: Text('خيار سحب للمستخدمين في سوريا'))),
      const Divider(),
      const Text('النموذج المقترح: 100 كونزا = 1 فُل • حد السحب 500 فُل • النسبة النهائية تُضبط قبل الإطلاق'),
    ],
  );
  Widget _balance(String name, String value, String sub) => Card(
    color: const Color(0xFF171020),
    child: ListTile(title: Text(name), subtitle: Text(sub), trailing: Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
  );
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override
  Widget build(BuildContext context) => _SimplePage(
    title: 'حسابي',
    icon: Icons.person,
    children: [
      const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
      const SizedBox(height: 12),
      const Center(child: Text('مستخدم جديد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const SizedBox(height: 18),
      ListTile(leading: const Icon(Icons.group_add), title: const Text('دعوة الأصدقاء'), subtitle: const Text('اجمع لفات عجلة الحظ')),
      ListTile(leading: const Icon(Icons.settings), title: const Text('الإعدادات')),
      ListTile(leading: const Icon(Icons.help_outline), title: const Text('الدعم')),
    ],
  );
}

class _SimplePage extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  const _SimplePage({required this.title, required this.icon, required this.children});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Row(children: [Icon(icon), const SizedBox(width: 10), Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900))]),
      const SizedBox(height: 22),
      ...children,
    ],
  );
}
